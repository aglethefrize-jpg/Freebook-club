// Exécuter UNE SEULE FOIS, en local, avec : node set-admin-claim.js <UID_ADMIN>
//
// 1. Va dans Firebase Console > Paramètres du projet > Comptes de service
//    > "Générer une nouvelle clé privée", place le fichier téléchargé
//    à côté de ce script sous le nom serviceAccountKey.json.
// 2. Trouve ton UID dans Firebase Console > Authentication > Users
//    (le compte que tu utilises déjà pour te connecter au panneau admin).
// 3. npm install firebase-admin, puis lance ce script avec ton UID.

const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });

const uid = process.argv[2];
if (!uid) {
  console.error('Usage : node set-admin-claim.js <UID>');
  process.exit(1);
}

admin.auth().setCustomUserClaims(uid, { admin: true })
  .then(() => {
    console.log(`Rôle admin attribué à l'utilisateur ${uid}.`);
    console.log('Déconnecte-toi puis reconnecte-toi sur le site pour que le rôle prenne effet.');
    process.exit(0);
  })
  .catch(err => {
    console.error(err);
    process.exit(1);
  });
