# Guide de déploiement — étape par étape

Ce guide suppose que tu pars de zéro sur ton ordinateur (pas encore d'outils
installés). Compte 20-30 minutes la première fois.

---

## Étape 1 — Installer Node.js

Firebase (l'outil en ligne de commande) a besoin de Node.js pour fonctionner.

1. Va sur **https://nodejs.org**
2. Télécharge la version **LTS** (le bouton principal, recommandé)
3. Installe-la comme n'importe quel logiciel (clique "Suivant" partout)

Pour vérifier que c'est installé, ouvre une invite de commandes :
- **Windows** : appuie sur la touche Windows, tape `cmd`, appuie sur Entrée
- **Mac** : appuie sur Cmd+Espace, tape `Terminal`, appuie sur Entrée

Dans la fenêtre noire qui s'ouvre, tape :
```
node -v
```
et appuie sur Entrée. Si un numéro de version s'affiche (ex: `v20.11.0`),
c'est bon.

---

## Étape 2 — Installer l'outil Firebase

Dans la même fenêtre (invite de commandes / Terminal), tape :
```
npm install -g firebase-tools
```
Appuie sur Entrée et attends que ça se termine (ça peut prendre 1-2 minutes).

Vérifie que ça a fonctionné :
```
firebase --version
```

---

## Étape 3 — Te connecter à ton compte Firebase

Toujours dans la même fenêtre :
```
firebase login
```
Une page va s'ouvrir dans ton navigateur — connecte-toi avec le compte Google
qui gère ton projet Firebase (`e-book-club-3f6c6`), puis autorise l'accès.
Reviens ensuite à la fenêtre noire : elle doit afficher un message de succès.

---

## Étape 4 — Extraire l'archive du site

1. Télécharge le fichier `ebook-club-firebase.zip` fourni plus haut
2. Trouve-le dans ton dossier "Téléchargements"
3. **Clic droit dessus** > **"Extraire tout..."** (Windows) ou double-clic (Mac)
4. Choisis un endroit simple à retrouver, par exemple directement sur ton
   Bureau — tu obtiens un dossier `ebook-club-firebase` contenant plusieurs
   fichiers et sous-dossiers (`public`, `functions`, `scripts`, etc.)

---

## Étape 5 — Se placer dans ce dossier depuis l'invite de commandes

Dans la fenêtre noire, tape `cd ` (avec un espace après), puis **glisse-dépose
le dossier extrait** directement dans la fenêtre — le chemin s'écrit tout
seul. Appuie sur Entrée.

Exemple (ce que ça donne une fois rempli) :
```
cd C:\Users\TonNom\Desktop\ebook-club-firebase
```
ou sur Mac :
```
cd /Users/TonNom/Desktop/ebook-club-firebase
```

Vérifie que tu es au bon endroit :
```
dir
```
(Windows) ou
```
ls
```
(Mac) — tu dois voir apparaître `firebase.json`, `public`, `functions`, etc.
**Toutes les commandes suivantes se tapent depuis cette même fenêtre, sans la
fermer.**

---

## Étape 6 — Relier ce dossier à ton projet Firebase

```
firebase use e-book-club-3f6c6
```

---

## Étape 7 — Installer les dépendances des Cloud Functions

```
cd functions
npm install
```
Attends que ça se termine (peut prendre 1-2 minutes), puis reviens au dossier
principal :
```
cd ..
```

---

## Étape 8 — Renseigner ta vraie clé FedaPay

Avant de déployer, ouvre le fichier `public/index.html` avec un éditeur de
texte simple (clic droit > "Ouvrir avec" > Bloc-notes, ou installe
[VS Code](https://code.visualstudio.com/) qui est plus confortable).

Utilise **Ctrl+F** (Rechercher) pour trouver :
```
REMPLACE_PAR_TA_VRAIE_CLE_PUBLIQUE_LIVE
```
Remplace ce texte par ta vraie clé publique FedaPay (Tableau de bord FedaPay
> Clés API > celle qui commence par `pk_live_`), puis enregistre le fichier
(Ctrl+S).

Vérifie aussi la valeur `COUNTRY_CODE = '229'` (indicatif Bénin) un peu plus
haut dans le même fichier : laisse-la telle quelle si tes clients sont au
Bénin.

---

## Étape 9 — Déployer

Retour dans l'invite de commandes (toujours dans le dossier
`ebook-club-firebase`) :
```
firebase deploy
```
Ça déploie en une seule commande : le site, les règles de sécurité, le
stockage des fichiers et la Cloud Function de vérification des paiements.
La première fois, ça peut prendre 3-5 minutes — laisse tourner sans fermer la
fenêtre.

À la fin, deux lignes importantes s'affichent :
- **Hosting URL** : l'adresse de ton site (à partager avec tes clients)
- **Function URL** (pour `fedapayWebhook`) : à copier, elle sert à l'étape suivante

---

## Étape 10 — Créer le webhook côté FedaPay

1. Tableau de bord FedaPay > **Webhooks** > **Créer un Webhook**
2. Colle l'URL de la fonction `fedapayWebhook` obtenue à l'étape précédente
3. Sélectionne l'événement `transaction.approved`
4. Enregistre

(Le secret de ce webhook doit déjà être configuré côté Firebase — c'est ce
que tu m'as indiqué avoir fait.)

---

## Étape 11 — T'attribuer le rôle administrateur (une seule fois)

1. Va dans **Firebase Console** > **Paramètres du projet** (icône ⚙️) >
   **Comptes de service**
2. Clique **"Générer une nouvelle clé privée"** — un fichier se télécharge
3. Renomme ce fichier en `serviceAccountKey.json` et place-le dans le
   sous-dossier `scripts` du projet extrait
4. Trouve ton UID : **Firebase Console** > **Authentication** > **Users** >
   repère la ligne du compte que tu utilises pour te connecter au panneau
   admin du site, copie son "User UID"
5. Dans l'invite de commandes :
```
cd scripts
npm install firebase-admin
node set-admin-claim.js TON_UID_ICI
```
(remplace `TON_UID_ICI` par l'UID copié à l'étape 4)

Un message de confirmation s'affiche. Retourne ensuite sur le site, déconnecte
-toi du panneau admin puis reconnecte-toi pour que le rôle prenne effet.

---

## Si tu dois republier plus tard (après une modification)

Une fois toute cette installation faite, tu n'as plus besoin de refaire
toutes les étapes : ouvre juste l'invite de commandes, `cd` vers le dossier
du projet, et retape :
```
firebase deploy
```

---

## Point d'attention : autorisation IAM pour les liens signés

`getProtectedFileUrl` (qui délivre les liens temporaires vers le PDF et
l'audio) génère des liens signés. Le compte de service par défaut des Cloud
Functions n'a pas toujours la permission nécessaire pour ça. Si tu obtiens
une erreur du type `IAM signBlob permission denied` en testant :

1. Va sur **Google Cloud Console** (console.cloud.google.com) > **IAM et
   administration** > **IAM**
2. Trouve le compte `e-book-club-3f6c6@appspot.gserviceaccount.com`
3. Clique sur le crayon (modifier) et ajoute-lui le rôle
   **"Créateur de jetons du compte de service"** ("Service Account Token
   Creator")

---

## Après le premier vrai paiement

Dans l'invite de commandes, depuis le dossier du projet :
```
firebase functions:log
```
Vérifie que les champs lus par `functions/index.js`
(`transaction.customer.phone_number.number`, `transaction.amount`,
`transaction.description`) correspondent bien à ce que FedaPay envoie
réellement — ajuste le fichier si un nom diffère, puis relance
`firebase deploy` pour republier la correction.
