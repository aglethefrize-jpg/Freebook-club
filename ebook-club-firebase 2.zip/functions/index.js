const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { Webhook } = require('fedapay');

admin.initializeApp();
const db = admin.firestore();

// Durée de chaque formule, en millisecondes
const DURATION_MS = {
  '24h': 24 * 60 * 60 * 1000,
  'weekly': 7 * 24 * 60 * 60 * 1000,
  'monthly': 30 * 24 * 60 * 60 * 1000,
  'annual': 365 * 24 * 60 * 60 * 1000
};

// Montant minimum attendu par formule (FCFA). Sert à rejeter une transaction
// approuvée mais dont le montant ne correspond à aucune formule connue.
const EXPECTED_AMOUNTS = {
  '24h': 300,
  'weekly': 1200,
  'monthly': 3500,
  'annual': 25000
};

// Indicatif pays utilisé pour reconstituer le numéro au format E.164
// (doit correspondre exactement au format utilisé par Firebase Phone Auth
// côté client, ex: +22997000000). Change "229" si tes clients ne sont pas au Bénin.
const COUNTRY_CODE = '229';

function normalizeToE164(rawNumber) {
  const digits = String(rawNumber || '').replace(/\D/g, '');
  return digits.startsWith(COUNTRY_CODE) ? `+${digits}` : `+${COUNTRY_CODE}${digits}`;
}

// Secret du webhook FedaPay (PAS la clé publique/privée de paiement).
// À définir avant déploiement avec :
//   firebase functions:config:set fedapay.webhook_secret="wh_live_xxxxxxxx"
const endpointSecret = functions.config().fedapay && functions.config().fedapay.webhook_secret;

/**
 * Point de terminaison à donner à FedaPay (section Webhooks du tableau de bord).
 * C'est la SEULE source de vérité pour l'activation d'un Pass : le client ne peut
 * plus jamais activer un abonnement lui-même, seul ce code serveur le peut,
 * après avoir vérifié la signature FedaPay.
 */
exports.fedapayWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers['x-fedapay-signature'];
  let event;

  try {
    // req.rawBody est fourni automatiquement par Cloud Functions for Firebase
    event = Webhook.constructEvent(req.rawBody, sig, endpointSecret);
  } catch (err) {
    console.error('Signature webhook invalide :', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  if (event.name !== 'transaction.approved') {
    // On accuse quand même réception pour éviter les re-tentatives inutiles de FedaPay.
    res.status(200).send('ignored');
    return;
  }

  try {
    const transaction = event.entity;
    // NB : imprime `console.log(JSON.stringify(transaction))` lors de ton premier
    // test réel et vérifie ces chemins de champs contre le payload effectivement reçu —
    // la structure exacte peut varier légèrement selon la version de l'API FedaPay.
    const phoneRaw = transaction && transaction.customer && transaction.customer.phone_number
      && transaction.customer.phone_number.number;
    const amount = transaction && transaction.amount;
    const description = transaction && transaction.description || '';

    const planType =
      Object.keys(EXPECTED_AMOUNTS).find(p => description.includes(p)) ||
      Object.keys(EXPECTED_AMOUNTS).find(p => amount === EXPECTED_AMOUNTS[p]);

    if (!phoneRaw || !planType || amount < EXPECTED_AMOUNTS[planType]) {
      console.error('Transaction approuvée mais données incohérentes — activation refusée', {
        phoneRaw, amount, planType, description
      });
      res.status(200).send('ok');
      return;
    }

    const phoneId = normalizeToE164(phoneRaw);
    const now = Date.now();
    const expiresAt = now + DURATION_MS[planType];

    await db.collection('subscribers').doc(phoneId).set({
      planType,
      purchasedAt: now,
      expiresAt,
      lastTransactionId: transaction.id
    }, { merge: true });

    console.log(`Pass activé pour ${phoneId} (${planType}) jusqu'au ${new Date(expiresAt).toISOString()}`);
    res.status(200).send('ok');
  } catch (err) {
    console.error('Erreur de traitement du webhook :', err);
    // On renvoie quand même 200 : FedaPay considérerait un 5xx comme un échec
    // et redéclencherait le webhook en boucle sur une erreur de notre code.
    res.status(200).send('error-logged');
  }
});

/**
 * Délivre un lien de téléchargement TEMPORAIRE (10 min) vers le PDF ou l'audio
 * d'une œuvre, après avoir revérifié ici, côté serveur, que le Pass est actif.
 *
 * C'est volontairement le SEUL moyen d'obtenir ces fichiers : storage.rules
 * refuse toute lecture directe (`allow read: if false`), et oeuvres_protected
 * ne stocke que le CHEMIN du fichier, jamais un lien de téléchargement — un
 * tel lien, une fois généré par le SDK client, resterait valable pour toujours
 * même après l'expiration du Pass. Un lien signé de courte durée, régénéré à
 * chaque écoute/lecture, garantit le verrouillage automatique en fin d'abonnement.
 */
exports.getProtectedFileUrl = functions.https.onCall(async (data, context) => {
  if (!context.auth || !context.auth.token.phone_number) {
    throw new functions.https.HttpsError('unauthenticated', 'Connexion requise.');
  }

  const { bookId, fileType } = data || {};
  if (!bookId || (fileType !== 'audio' && fileType !== 'pdf')) {
    throw new functions.https.HttpsError('invalid-argument', 'Requête invalide.');
  }

  const isAdmin = context.auth.token.admin === true;

  if (!isAdmin) {
    const subDoc = await db.collection('subscribers').doc(context.auth.token.phone_number).get();
    const sub = subDoc.data();
    if (!sub || !sub.expiresAt || sub.expiresAt < Date.now()) {
      throw new functions.https.HttpsError('permission-denied', 'Pass inactif ou expiré.');
    }
  }

  const bookDoc = await db.collection('oeuvres_protected').doc(bookId).get();
  if (!bookDoc.exists) {
    throw new functions.https.HttpsError('not-found', "Fichier introuvable.");
  }

  const path = fileType === 'audio' ? bookDoc.data().audioPath : bookDoc.data().pdfPath;
  if (!path) {
    throw new functions.https.HttpsError('not-found', "Fichier introuvable.");
  }

  const [url] = await admin.storage().bucket().file(path).getSignedUrl({
    action: 'read',
    expires: Date.now() + 10 * 60 * 1000
  });

  return { url };
});
